import { createClient } from '@supabase/supabase-js';

// Configuração do Supabase - MODIFIQUE COM SEUS DADOS
const supabaseUrl = 'https://SEU_URL_SUPABASE.supabase.co'; // MODIFIQUE: Substitua pelo URL do seu projeto Supabase
const supabaseKey = 'SUA_CHAVE_API_PUBLICA'; // MODIFIQUE: Substitua pela sua chave API pública do Supabase

// Criação do cliente Supabase para interação com o banco de dados
export const supabase = createClient(supabaseUrl, supabaseKey);

// Função para verificar se o usuário está autenticado
export const checkAuth = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  return user;
};

// Função para fazer logout do sistema
export const signOut = async () => {
  await supabase.auth.signOut();
};

// Tipo para usuários do sistema
export interface User {
  id: string;
  email: string;
  role: 'admin' | 'member' | 'setter';
  username: string;
  is_online: boolean;
  created_at: string;
}

// Tipo para itens de venda
export interface Item {
  id: string;
  name: string;
  description: string;
  price: number;
  emoji: string;
  quantity: number;
  created_at: string;
  updated_at: string;
}

// Tipo para vendas
export interface Sale {
  id: string;
  item_id: string;
  seller_id: string;
  buyer_name: string;
  quantity: number;
  total_price: number;
  seller_profit: number; // 20% do valor
  owner_profit: number; // 80% do valor
  created_at: string;
}